package com.example.sign_glove_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
